var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var api_exports = {};
__export(api_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(api_exports);
var import_express = __toESM(require("express"), 1);
var import_serverless_http = __toESM(require("serverless-http"), 1);
var import_cors = __toESM(require("cors"), 1);
var import_supabase_js = require("@supabase/supabase-js");
const app = (0, import_express.default)();
app.use((0, import_cors.default)());
app.use(import_express.default.json());
const supabaseUrl = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!supabaseUrl || !supabaseKey) {
  console.error("\u274C Supabase configuration missing!");
  console.error("URL present:", !!supabaseUrl);
  console.error("Key present:", !!supabaseKey);
}
const supabase = supabaseUrl && supabaseKey ? (0, import_supabase_js.createClient)(supabaseUrl, supabaseKey) : null;
const checkConfig = (req, res, next) => {
  if (!supabase) {
    return res.status(500).json({
      error: "Backend configuration error (Supabase keys missing)",
      details: "Check Netlify environment variables."
    });
  }
  next();
};
const router = import_express.default.Router();
router.use(checkConfig);
router.post("/auth/login", async (req, res) => {
  const { username, password } = req.body;
  const { data: user, error } = await supabase.from("users").select("*").eq("username", username).single();
  if (error || !user || user.password_hash !== password) {
    return res.status(401).json({ error: "Identifiants invalides" });
  }
  res.json({ user });
});
router.get("/projects", async (req, res) => {
  const { data, error } = await supabase.from("projects").select("*, lines(*, machines(*))");
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});
router.get("/planning", async (req, res) => {
  const { data, error } = await supabase.from("planning").select("*").order("date", { ascending: true });
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});
router.get("/checklist", async (req, res) => {
  const { data, error } = await supabase.from("checklist_items").select("*");
  if (error) return res.status(500).json({ error: error.message });
  res.json({ items: data });
});
router.get("/audits", async (req, res) => {
  const { data, error } = await supabase.from("audits").select("*, audit_answers(*)");
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});
router.post("/audits", async (req, res) => {
  const { audit, answers } = req.body;
  const { data: newAudit, error: auditErr } = await supabase.from("audits").insert([audit]).select().single();
  if (auditErr) return res.status(500).json({ error: auditErr.message });
  const answersToInsert = answers.map((a) => ({ ...a, audit_id: newAudit.id }));
  const { error: ansErr } = await supabase.from("audit_answers").insert(answersToInsert);
  if (ansErr) return res.status(500).json({ error: ansErr.message });
  res.json(newAudit);
});
router.get("/users", async (req, res) => {
  const { data, error } = await supabase.from("users").select("*");
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});
router.get("/settings", async (req, res) => {
  res.json({
    companyName: "Audit TPM",
    planningYear: 2026,
    started: true
  });
});
router.post("/planning/regenerate", async (req, res) => {
  res.json({ message: "Regeneration successful (Stub)" });
});
app.use("/", router);
app.get("/health", (req, res) => res.json({ status: "ok", config: !!supabase }));
const handler = (0, import_serverless_http.default)(app, {
  basePath: "/.netlify/functions/api"
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
